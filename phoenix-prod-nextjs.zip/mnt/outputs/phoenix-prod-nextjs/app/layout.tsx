import type { Metadata } from 'next'
import './globals.css'
import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'
import CookieBanner from '@/components/CookieBanner'
import { SITE } from '@/lib/constants'

export const metadata: Metadata = {
  metadataBase: new URL(SITE.url),
  title: {
    default: `${SITE.name} | Agence vidéo & drone en Guadeloupe`,
    template: `%s | ${SITE.name}`,
  },
  description: SITE.description,
  keywords: [
    'agence vidéo Guadeloupe',
    'drone Guadeloupe',
    'production audiovisuelle Antilles',
    'stratégie marketing Guadeloupe',
    'tournage drone 971',
    'film institutionnel Guadeloupe',
    'Rcky Digital',
    'Phoenix Prod',
  ],
  authors: [{ name: SITE.agency }],
  openGraph: {
    type: 'website',
    locale: 'fr_FR',
    url: SITE.url,
    siteName: SITE.name,
    title: `${SITE.name} | Production vidéo & drone en Guadeloupe`,
    description: SITE.description,
  },
  robots: {
    index: true,
    follow: true,
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <body>
        <Navbar />
        <main>{children}</main>
        <Footer />
        <CookieBanner />
      </body>
    </html>
  )
}
