import { NextRequest, NextResponse } from 'next/server'

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const name = formData.get('name') as string
    const email = formData.get('email') as string
    const phone = formData.get('phone') as string
    const message = formData.get('message') as string

    if (!name || !email || !message) {
      return NextResponse.json({ error: 'Champs requis manquants' }, { status: 400 })
    }

    // ================================================================
    // OPTION 1 — Resend (recommandé, gratuit jusqu'à 100 emails/jour)
    // 1. Créer un compte sur resend.com
    // 2. Ajouter RESEND_API_KEY dans .env.local
    // 3. Décommenter le bloc ci-dessous
    // ================================================================
    //
    // const { Resend } = await import('resend')
    // const resend = new Resend(process.env.RESEND_API_KEY)
    // await resend.emails.send({
    //   from: 'contact@phoenixprod.fr',
    //   to: process.env.CONTACT_EMAIL || 'contact@rckydigital.com',
    //   subject: `Nouveau message de ${name}`,
    //   html: `
    //     <h2>Nouveau message via le site Phoenix Prod</h2>
    //     <p><strong>Nom :</strong> ${name}</p>
    //     <p><strong>Email :</strong> ${email}</p>
    //     <p><strong>Téléphone :</strong> ${phone || 'Non renseigné'}</p>
    //     <p><strong>Message :</strong></p>
    //     <p>${message.replace(/\n/g, '<br>')}</p>
    //   `,
    // })

    // En attendant la configuration email, on log dans la console (dev uniquement)
    console.log('Nouveau message de contact:', { name, email, phone, message })

    // Redirection vers une page de confirmation (à créer) ou retour contact
    return NextResponse.redirect(new URL('/contact?sent=true', request.url))
  } catch (error) {
    console.error('Erreur formulaire contact:', error)
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 })
  }
}
